#!/usr/bin/env bash
# Creates one public GitHub repo per project folder. Requires git and the GitHub CLI (gh auth login).
set -e
for d in ai-traffic-management smart-parking ai-waste-management ai-water-management air-pollution-monitoring ai-natural-disaster-prediction; do
  (cd "$d" && git init -b main && git add . && git commit -m "Initial commit" && gh repo create "$d" --public --source=. --push)
done
