# AI Waste Management

Sorts waste with a small machine-learning classifier and plans collection routes for full bins only.

> **Status:** concept prototype. It runs on simulated data and has not been deployed or tested with real hardware or real-world data.

## What it is
Two Python modules. `waste_classifier.py` is a k-nearest-neighbour classifier that labels an item as organic, metal, plastic/paper, or general waste from three sensor-style features. `collection_planner.py` builds a route that visits only bins that are at least 70% full.

## Why I made it
Mixed waste is hard to recycle, and trucks often visit bins that are still empty. Sorting at the source and collecting only when needed saves fuel and improves recycling.

## Who it is for
Municipal waste teams, campuses, and students interested in smart-city and sustainability projects.

## How it was made
1. Items are described by moisture (%), metal signal (0-1), and light transmission (0-1). Simulated training data is generated per class.
2. k-NN (k=5) is written from scratch, with features scaled to the same range.
3. Bins have coordinates and a fill level. A greedy nearest-neighbour route starts at the depot, visits only bins above the threshold, and returns.
4. The route length is compared with visiting every bin.

## Languages and tools
Python 3 (standard library only). Tests with pytest.

## Run it
```bash
python waste_classifier.py
python collection_planner.py
```

Example output:
```text
Held-out accuracy on simulated data: 100%
Visit 4 of 15 bins: BIN-04 -> BIN-15 -> BIN-02 -> BIN-07
Route length 26.2 km vs 51.2 km if every bin is visited
```

Run the tests with `pip install pytest` and then `pytest`.

## Limitations
The classifier's classes are well separated by design, so its accuracy is unrealistically high. Real waste needs a camera and a trained image model. The route planner is greedy, not optimal.

## Future work
Train a CNN on a real waste-image dataset, add ultrasonic fill-level sensors to bins, and use a proper vehicle-routing solver.

## Author
Sakthivel. Computer Science and Engineering, Lovely Professional University.

## License
MIT. See [LICENSE](LICENSE).
