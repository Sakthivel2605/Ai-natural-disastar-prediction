"""Tiny k-nearest-neighbour waste sorter written without external libraries.

Each item is described by three sensor-style features (all simulated here):
moisture (0-100 %), metal_signal (0-1) and light_transmission (0-1).
"""
import math
import random
from collections import Counter

CLASSES = ["organic", "metal", "plastic_paper", "general"]


def make_dataset(n_per_class=60, seed=7):
    rng = random.Random(seed)
    # (moisture range, metal range, transmission range) per class
    spec = {
        "organic": ((60, 95), (0.0, 0.1), (0.0, 0.2)),
        "metal": ((0, 15), (0.7, 1.0), (0.0, 0.1)),
        "plastic_paper": ((0, 25), (0.0, 0.15), (0.3, 0.9)),
        "general": ((25, 60), (0.0, 0.3), (0.0, 0.4)),
    }
    data = []
    for label, ranges in spec.items():
        for _ in range(n_per_class):
            data.append((tuple(rng.uniform(*r) for r in ranges), label))
    rng.shuffle(data)
    return data


def _scale(x):
    return (x[0] / 100.0, x[1], x[2])


def predict(train, item, k=5):
    item = _scale(item)
    nearest = sorted(train, key=lambda s: math.dist(_scale(s[0]), item))[:k]
    return Counter(label for _, label in nearest).most_common(1)[0][0]


def accuracy(train, test, k=5):
    return sum(predict(train, x, k) == y for x, y in test) / len(test)


if __name__ == "__main__":
    data = make_dataset()
    split = int(len(data) * 0.8)
    train, test = data[:split], data[split:]
    print(f"Held-out accuracy on simulated data: {accuracy(train, test):.0%}")
    print("Wet item, no metal ->", predict(train, (82, 0.02, 0.05)))
