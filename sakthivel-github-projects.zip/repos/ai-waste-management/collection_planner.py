"""Plan a collection route that only visits bins that are nearly full."""
import math
import random


def make_bins(n=15, seed=3):
    rng = random.Random(seed)
    return [{"id": f"BIN-{i:02d}", "x": rng.uniform(0, 10), "y": rng.uniform(0, 10),
             "fill": rng.randint(5, 100)} for i in range(1, n + 1)]


def plan_route(bins, threshold=70, depot=(0.0, 0.0)):
    """Greedy nearest-neighbour route over bins with fill >= threshold."""
    todo = [b for b in bins if b["fill"] >= threshold]
    route, pos, dist = [], depot, 0.0
    while todo:
        nxt = min(todo, key=lambda b: math.dist(pos, (b["x"], b["y"])))
        dist += math.dist(pos, (nxt["x"], nxt["y"]))
        pos = (nxt["x"], nxt["y"])
        route.append(nxt)
        todo.remove(nxt)
    dist += math.dist(pos, depot)
    return route, dist


if __name__ == "__main__":
    bins = make_bins()
    route, dist = plan_route(bins)
    _, all_dist = plan_route(bins, threshold=0)
    print(f"Visit {len(route)} of {len(bins)} bins: " + " -> ".join(b["id"] for b in route))
    print(f"Route length {dist:.1f} km vs {all_dist:.1f} km if every bin is visited")
