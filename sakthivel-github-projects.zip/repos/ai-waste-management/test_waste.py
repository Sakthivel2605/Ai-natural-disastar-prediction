import waste_classifier as wc
import collection_planner as cp


def test_classifier_is_accurate_on_simulated_data():
    data = wc.make_dataset()
    split = int(len(data) * 0.8)
    assert wc.accuracy(data[:split], data[split:]) > 0.85


def test_planner_only_visits_full_bins():
    bins = cp.make_bins()
    route, _ = cp.plan_route(bins, threshold=70)
    assert all(b["fill"] >= 70 for b in route)
