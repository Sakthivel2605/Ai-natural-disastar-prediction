"""Air pollution monitoring: PM2.5 readings -> AQI, categories, alerts, CSV."""
import csv
import random

# (conc_low, conc_high, aqi_low, aqi_high, category): US EPA-style PM2.5 breakpoints.
# Check the current EPA / CPCB tables before using for anything real.
BREAKPOINTS = [
    (0.0, 12.0, 0, 50, "Good"),
    (12.1, 35.4, 51, 100, "Moderate"),
    (35.5, 55.4, 101, 150, "Unhealthy for sensitive groups"),
    (55.5, 150.4, 151, 200, "Unhealthy"),
    (150.5, 250.4, 201, 300, "Very unhealthy"),
    (250.5, 500.4, 301, 500, "Hazardous"),
]
ALERT_AQI = 150


def pm25_to_aqi(c):
    c = round(c, 1)
    for lo, hi, a_lo, a_hi, name in BREAKPOINTS:
        if c <= hi:
            return round((a_hi - a_lo) / (hi - lo) * (c - lo) + a_lo), name
    return 500, "Hazardous"


def simulate_readings(stations, hours=24, seed=5):
    rng = random.Random(seed)
    rows = []
    for name, base in stations.items():
        for h in range(hours):
            peak = 35 if name == "Industrial Zone" and 7 <= h <= 11 else 0   # morning event
            rows.append({"station": name, "hour": h, "pm25": max(2.0, rng.gauss(base + peak, 4))})
    return rows


def analyse(rows):
    for r in rows:
        r["aqi"], r["category"] = pm25_to_aqi(r["pm25"])
        r["alert"] = r["aqi"] > ALERT_AQI
    return rows


def write_csv(rows, path="air_quality_report.csv"):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["station", "hour", "pm25", "aqi", "category", "alert"])
        w.writeheader()
        w.writerows({**r, "pm25": round(r["pm25"], 1)} for r in rows)


if __name__ == "__main__":
    stations = {"Residential Area": 18, "City Centre": 38, "Industrial Zone": 45}
    rows = analyse(simulate_readings(stations))
    write_csv(rows)
    for s in stations:
        mine = [r for r in rows if r["station"] == s]
        avg = sum(r["aqi"] for r in mine) / len(mine)
        print(f"{s:18s} avg AQI {avg:5.0f}  alerts: {sum(r['alert'] for r in mine)}")
    print("Full report written to air_quality_report.csv")
