from air_quality import pm25_to_aqi


def test_known_breakpoints():
    assert pm25_to_aqi(0) == (0, "Good")
    assert pm25_to_aqi(12.0) == (50, "Good")
    assert pm25_to_aqi(35.4)[0] == 100
    assert pm25_to_aqi(300)[1] == "Hazardous"
