# Air Pollution Monitoring

Turns PM2.5 sensor readings into AQI values, categories, alerts, and a CSV report.

> **Status:** concept prototype. It runs on simulated data and has not been deployed or tested with real hardware or real-world data.

## What it is
A Python tool that converts PM2.5 concentrations to an Air Quality Index, labels each reading (Good to Hazardous), raises an alert above AQI 150, and writes a CSV report. It extends my Smart Air Quality System to several areas.

## Why I made it
People can't act on air pollution they can't see. A clear index and alerts help communities avoid exposure.

## Who it is for
Residents near busy roads or industry, schools, local authorities, and students working on environmental IoT.

## How it was made
1. Three simulated stations (Residential Area, City Centre, Industrial Zone) report hourly PM2.5, with a morning pollution event at the industrial station.
2. `pm25_to_aqi` interpolates linearly inside US EPA-style breakpoint bands.
3. Readings above AQI 150 are flagged as alerts.
4. Results are summarised per station and saved to `air_quality_report.csv`.

## Languages and tools
Python 3 (standard library only). Tests with pytest.

## Run it
```bash
python air_quality.py
```

Example output:
```text
Residential Area   avg AQI    61  alerts: 0
Industrial Zone    avg AQI   135  alerts: 5
```

Run the tests with `pip install pytest` and then `pytest`.

## Limitations
Uses older US EPA-style breakpoints for PM2.5 only. India reports AQI under CPCB rules, so check the current official tables before relying on values. Data is simulated and there is no real sensor link.

## Future work
Read a real sensor (for example PMS5003 on Arduino/ESP32), add PM10, CO2, and gases, switch to CPCB breakpoints, and add a live map.

## Author
Sakthivel. Computer Science and Engineering, Lovely Professional University.

## License
MIT. See [LICENSE](LICENSE).
