# Sakthivel's Project Concepts

Six small, runnable prototypes for smart-city and IoT ideas. Each folder is a separate project that can be published as its own GitHub repository. All of them use simulated data and are concept prototypes, not deployed systems.

| Project | What it does | Languages |
|---|---|---|
| [ai-traffic-management](ai-traffic-management) | Adaptive traffic signal vs fixed timing | Python |
| [smart-parking](smart-parking) | Free-slot detection and nearest-slot guidance | Python, SQL, C++ (Arduino) |
| [ai-waste-management](ai-waste-management) | Waste sorting (k-NN) and collection routes | Python |
| [ai-water-management](ai-water-management) | Night-flow leak detection and pump control | Python |
| [air-pollution-monitoring](air-pollution-monitoring) | PM2.5 to AQI, alerts, CSV report | Python |
| [ai-natural-disaster-prediction](ai-natural-disaster-prediction) | Flood risk prediction | Python, scikit-learn |

## Publish each project as its own repository
Create an empty repository on GitHub for each folder, then from this directory run (with the GitHub CLI installed and logged in):

```bash
bash publish_to_github.sh
```

Or do one project by hand:

```bash
cd smart-parking
git init -b main
git add .
git commit -m "Initial commit"
gh repo create smart-parking --public --source=. --push
```

Suggested repository topics: `python`, `iot`, `smart-city`, `simulation`, `student-project`.
