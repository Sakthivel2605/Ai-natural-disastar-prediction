"""Smart parking: slot occupancy from ultrasonic readings, stored in SQLite."""
import argparse
import random
import sqlite3
from datetime import datetime

DB = "parking.db"
OCCUPIED_BELOW_CM = 30   # a car under the sensor reads closer than this


def connect(path=DB):
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    return con


def init(con, slots=12):
    con.execute("DROP TABLE IF EXISTS slots")
    con.execute("""CREATE TABLE slots (
        slot_id TEXT PRIMARY KEY,
        entrance_m REAL NOT NULL,       -- walking distance from the entrance
        occupied INTEGER NOT NULL DEFAULT 0,
        distance_cm REAL,
        updated_at TEXT)""")
    for i in range(1, slots + 1):
        con.execute("INSERT INTO slots (slot_id, entrance_m) VALUES (?, ?)",
                    (f"A{i:02d}", 5 + 3 * i))
    con.commit()


def ingest(con, slot_id, distance_cm):
    """Store one sensor reading (this is what the microcontroller would send)."""
    occupied = 1 if distance_cm < OCCUPIED_BELOW_CM else 0
    con.execute("UPDATE slots SET occupied=?, distance_cm=?, updated_at=? WHERE slot_id=?",
                (occupied, distance_cm, datetime.now().isoformat(timespec="seconds"), slot_id))
    con.commit()


def simulate(con, seed=None):
    rng = random.Random(seed)
    for row in con.execute("SELECT slot_id FROM slots").fetchall():
        car = rng.random() < 0.6
        ingest(con, row["slot_id"], rng.uniform(8, 25) if car else rng.uniform(80, 200))


def status(con):
    free = con.execute("SELECT COUNT(*) FROM slots WHERE occupied=0").fetchone()[0]
    total = con.execute("SELECT COUNT(*) FROM slots").fetchone()[0]
    return free, total


def nearest_free(con):
    return con.execute("SELECT slot_id, entrance_m FROM slots WHERE occupied=0 "
                       "ORDER BY entrance_m LIMIT 1").fetchone()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("command", choices=["init", "simulate", "status", "nearest"])
    p.add_argument("--slots", type=int, default=12)
    p.add_argument("--seed", type=int)
    a = p.parse_args()
    con = connect()
    if a.command == "init":
        init(con, a.slots); print(f"Created {a.slots} slots")
    elif a.command == "simulate":
        simulate(con, a.seed); print("Sensor readings updated")
    elif a.command == "status":
        free, total = status(con); print(f"{free} of {total} slots free")
        for r in con.execute("SELECT slot_id, occupied FROM slots"):
            print(f"  {r['slot_id']}: {'occupied' if r['occupied'] else 'free'}")
    else:
        r = nearest_free(con)
        print(f"Go to slot {r['slot_id']} ({r['entrance_m']:.0f} m from entrance)" if r else "Parking is full")


if __name__ == "__main__":
    main()
