// Reference sketch for an Arduino + HC-SR04 ultrasonic sensor (one slot).
// Prints "<slot_id>,<distance_cm>" over serial once per second.
// Not tested on hardware. Pin numbers are examples; adjust to your wiring.
const int TRIG_PIN = 9;
const int ECHO_PIN = 10;
const char* SLOT_ID = "A01";

void setup() {
  Serial.begin(9600);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
}

void loop() {
  digitalWrite(TRIG_PIN, LOW);  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH); delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long duration = pulseIn(ECHO_PIN, HIGH, 30000);   // microseconds
  float distanceCm = duration * 0.0343 / 2.0;       // speed of sound
  Serial.print(SLOT_ID); Serial.print(","); Serial.println(distanceCm);
  delay(1000);
}
