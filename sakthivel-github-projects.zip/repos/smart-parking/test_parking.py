import parking


def test_reading_marks_slot_and_finds_nearest():
    con = parking.connect(":memory:")
    parking.init(con, 3)
    parking.ingest(con, "A01", 12)    # car present
    parking.ingest(con, "A02", 150)   # empty
    parking.ingest(con, "A03", 150)
    assert parking.status(con) == (2, 3)
    assert parking.nearest_free(con)["slot_id"] == "A02"
