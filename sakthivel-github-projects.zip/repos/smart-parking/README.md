# Smart Parking

Detects free parking slots with ultrasonic sensors and guides drivers to the nearest one.

> **Status:** concept prototype. It runs on simulated data and has not been deployed or tested with real hardware or real-world data.

## What it is
A Python and SQLite back end that stores one occupancy reading per parking slot, reports how many slots are free, and finds the free slot closest to the entrance. An Arduino sketch shows how an HC-SR04 ultrasonic sensor would send readings.

## Why I made it
Drivers lose time and fuel circling for a space. Knowing which slots are free in real time reduces congestion and frustration.

## Who it is for
Campuses, malls, and small car parks, and students learning how IoT sensors connect to a database.

## How it was made
1. The Arduino sketch measures distance with an ultrasonic sensor and prints `slot_id,distance_cm` over serial.
2. `ingest()` stores a reading in SQLite: a distance under 30 cm means a car is present.
3. SQL queries return the number of free slots and the free slot with the smallest walking distance to the entrance.
4. Without hardware, `simulate` generates random readings so the whole flow can be tried on a laptop.

## Languages and tools
Python 3, SQL (SQLite), C++ for the Arduino sketch (Arduino IDE). Tests with pytest.

## Run it
```bash
python parking.py init --slots 12
python parking.py simulate --seed 1
python parking.py status
python parking.py nearest
```

Example output:
```text
3 of 6 slots free
Go to slot A02 (11 m from entrance)
```

Run the tests with `pip install pytest` and then `pytest`.

## Limitations
The Arduino sketch is a reference and has not been tested on hardware. There is no serial reader, display board, or app yet. Readings are simulated by default.

## Future work
Read the serial port with pyserial, add a web dashboard or mobile app, use ESP32 with Wi-Fi/MQTT, and add reservations.

## Author
Sakthivel. Computer Science and Engineering, Lovely Professional University.

## License
MIT. See [LICENSE](LICENSE).
