from traffic_signal import simulate


def test_adaptive_beats_fixed_in_rush_hour():
    assert simulate("adaptive", "rush_ns")["avg_wait_s"] < simulate("fixed", "rush_ns")["avg_wait_s"]


def test_runs_for_every_scenario():
    for s in ("balanced", "rush_ns", "rush_ew"):
        assert simulate("adaptive", s, duration=600)["vehicles"] > 0
