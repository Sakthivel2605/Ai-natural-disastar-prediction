"""Adaptive vs fixed-time traffic signal simulation for a 4-way intersection.

One simulation step is one second. Two phases alternate: North/South (NS) and
East/West (EW). Each phase has a lost time (yellow + clearance) when it ends.
"""
import argparse
import random

DISCHARGE_RATE = 0.5   # vehicles per second per direction while green
LOST_TIME = 3          # seconds lost at every phase change
MIN_GREEN, MAX_GREEN = 10, 60

SCENARIOS = {          # arrival probability per second: (NS, EW) per direction
    "balanced": (0.12, 0.12),
    "rush_ns": (0.20, 0.06),
    "rush_ew": (0.06, 0.20),
}


class Intersection:
    def __init__(self, ns_rate, ew_rate, seed=42):
        self.rng = random.Random(seed)
        self.rates = {"NS": ns_rate, "EW": ew_rate}
        self.queues = {"NS": [0, 0], "EW": [0, 0]}   # two directions per phase
        self.credit = {"NS": [0.0, 0.0], "EW": [0.0, 0.0]}
        self.arrivals = 0
        self.queue_seconds = 0

    def arrive(self):
        for phase, rate in self.rates.items():
            for i in range(2):
                if self.rng.random() < rate:
                    self.queues[phase][i] += 1
                    self.arrivals += 1

    def discharge(self, phase):
        for i in range(2):
            self.credit[phase][i] += DISCHARGE_RATE
            while self.credit[phase][i] >= 1 and self.queues[phase][i] > 0:
                self.queues[phase][i] -= 1
                self.credit[phase][i] -= 1
            if self.queues[phase][i] == 0:
                self.credit[phase][i] = min(self.credit[phase][i], 1.0)

    def tick(self, green_phase):
        self.arrive()
        if green_phase:
            self.discharge(green_phase)
        self.queue_seconds += sum(sum(q) for q in self.queues.values())


def green_time(controller, junction, phase):
    if controller == "fixed":
        return 30
    # adaptive: time needed to clear the vehicles currently waiting
    waiting = sum(junction.queues[phase])
    return max(MIN_GREEN, min(MAX_GREEN, waiting))


def simulate(controller, scenario, duration=3600, seed=42):
    ns, ew = SCENARIOS[scenario]
    junction = Intersection(ns, ew, seed)
    t, phase = 0, "NS"
    while t < duration:
        for _ in range(green_time(controller, junction, phase)):
            if t >= duration:
                break
            junction.tick(phase)
            t += 1
        for _ in range(LOST_TIME):
            if t >= duration:
                break
            junction.tick(None)
            t += 1
        phase = "EW" if phase == "NS" else "NS"
    avg_wait = junction.queue_seconds / max(1, junction.arrivals)
    return {"vehicles": junction.arrivals, "avg_wait_s": round(avg_wait, 1),
            "left_in_queue": sum(sum(q) for q in junction.queues.values())}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--scenario", choices=SCENARIOS, default="rush_ns")
    p.add_argument("--duration", type=int, default=3600, help="seconds")
    a = p.parse_args()
    print(f"Scenario: {a.scenario}, duration: {a.duration}s")
    for c in ("fixed", "adaptive"):
        r = simulate(c, a.scenario, a.duration)
        print(f"{c:9s} vehicles={r['vehicles']:5d}  avg wait={r['avg_wait_s']:6.1f}s  "
              f"still queued={r['left_in_queue']}")


if __name__ == "__main__":
    main()
