# AI Traffic Management

An adaptive traffic-signal simulation that gives green time to the busiest road.

> **Status:** concept prototype. It runs on simulated data and has not been deployed or tested with real hardware or real-world data.

## What it is
A Python simulation of a four-way intersection. It compares a normal fixed-time signal (30 s per phase) with an adaptive controller that sets each green phase to the time needed to clear the vehicles currently waiting (between 10 and 60 seconds).

## Why I made it
Fixed-time signals waste green time on empty roads while other roads back up. I wanted to show how a simple data-driven rule can cut waiting time before any camera or AI model is added.

## Who it is for
Students and city planners exploring smart-city ideas, and anyone who wants a small, readable example of adaptive signal control.

## How it was made
1. Each simulated second, vehicles arrive randomly (Bernoulli arrivals) in each of the four directions.
2. Two phases alternate: North/South and East/West, with 3 seconds of lost time at every change.
3. While a phase is green, each direction discharges 0.5 vehicles per second.
4. The adaptive controller reads the queue lengths at the start of each phase and sets the green time. The fixed controller always uses 30 s.
5. Average wait per vehicle is the total queue-seconds divided by the number of arrivals.

## Languages and tools
Python 3 (standard library only). Tests with pytest.

## Run it
```bash
python traffic_signal.py --scenario rush_ns
python traffic_signal.py --scenario balanced
```

Example output:
```text
Scenario: balanced, duration: 3600s
fixed     vehicles= 1706  avg wait=  12.6s  still queued=6
adaptive  vehicles= 1706  avg wait=   7.1s  still queued=3
```

Run the tests with `pip install pytest` and then `pytest`.

## Limitations
Single intersection, simulated arrivals, no pedestrians, turning movements, or emergency vehicles. The 'AI' is a queue-based rule, not a trained model. In the heavy one-way rush scenario the gain is small.

## Future work
Add a camera-based vehicle counter (computer vision), reinforcement learning for the signal policy, and coordination between neighbouring junctions.

## Author
Sakthivel. Computer Science and Engineering, Lovely Professional University.

## License
MIT. See [LICENSE](LICENSE).
